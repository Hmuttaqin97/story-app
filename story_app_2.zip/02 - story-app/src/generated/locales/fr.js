
    // Do not modify this file by hand!
    // Re-generate this file by running lit-localize

    
    

    /* eslint-disable no-irregular-whitespace */
    /* eslint-disable @typescript-eslint/no-explicit-any */

    export const templates = {
      's04a2bb60eb38f246': `ajoute ton histoire`,
's0f136ff2c086b760': `réinitialiser`,
's116a8d48166d06f0': `Inscription réussie`,
's123467b419acbc07': `email`,
's1978bd4ba70d2159': `Échec de l'ajout de l'histoire`,
's24eb6ed15e6253d7': `description`,
's25a08d8d86e134df': `envoyer`,
's2b940301421633c3': `entrez la description ici`,
's37ee620e44d1533d': `Saisissez un texte de 5 à 125 lettres minimum`,
's3cf0c263cd2dcba3': `Vous avez déjà un compte ?`,
's3d5ec69a6bb3472e': `sombre`,
's45dab30b4d2d3c14': `Connexion`,
's4b1a493507b3a318': `mot de passe`,
's4c9c0860ebbb779a': `Échec de l'obtention de la localisation`,
's4e88ffdb99e2ac13': `la date`,
's51d0f228b37fd03e': `Je veux entendre ton histoire aujourd'hui`,
's52c7e91ac3b4c3b1': `suivant`,
's55a10969ca715e1a': `accueil`,
's5a0a1db9e8aa5cda': `Compte non trouvé !`,
's62f49131afb567ec': `données non trouvées`,
's63dc8e0c3a4e101c': `paramètres`,
's742c9c23d1339e9a': `Redirection vers la page de connexion`,
's791e05c31c49ee28': `changer de mot de passe`,
's7ae24e2336894d23': `Vous n'avez pas de compte ?`,
's7e529dba6c35eb7a': `dernière mise à jour`,
's839a089030f02437': `Ajout de l'histoire réussi`,
's854242b8a879835a': `ajouter une histoire`,
's861bcba4db199cb4': `connexion`,
's87f398d5a8c139c0': `clair`,
's90a714a4349ca0f1': `déconnexion`,
's94a644b5e0880579': `nom d'utilisateur`,
's9a6832609fd9c1bf': `adresse e-mail`,
'sa52127387350c01a': `réinitialiser les paramètres`,
'sa7a70bfb41a338db': `mot de passe`,
'sb1a4bc14542488cb': `Échec de l'inscription du compte !`,
'sb265cc26dbb527f9': `changer de nom`,
'sb56798071baac29e': `tableau de bord`,
'sb616cbe958dea2ee': `Connexion réussie`,
'sb7c4c1e6784787df': `profil`,
'sc22a9483cdfc43da': `compte`,
'sc4bcb1ba8e632252': `nom`,
'sd064987a26e82eb7': `changer de thème`,
'sd535cd6798034923': `envoyer en tant que`,
'sd93e3def078c6f4c': `invité`,
'sd93ff51dd0da1dbf': `Inscription`,
'sdb40d268bbd1a81c': `changer de langue`,
'sdeec2d9bd0d9a355': `bleu`,
'se96192ff1de6ff4d': `Supprimer le compte`,
'seb832a602c5b48df': `Inscription`,
'sf31e8cf85d601d2a': `précédent`,
'sf41b5558524d0412': `Redirection vers la page d'accueil`,
    };
  