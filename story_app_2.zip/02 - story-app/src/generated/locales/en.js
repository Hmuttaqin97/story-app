
    // Do not modify this file by hand!
    // Re-generate this file by running lit-localize

    
    

    /* eslint-disable no-irregular-whitespace */
    /* eslint-disable @typescript-eslint/no-explicit-any */

    export const templates = {
      's04a2bb60eb38f246': `add your story`,
's0f136ff2c086b760': `reset`,
's116a8d48166d06f0': `Account registration successful`,
's123467b419acbc07': `email`,
's1978bd4ba70d2159': `Failed to Add Story`,
's24eb6ed15e6253d7': `description`,
's25a08d8d86e134df': `send`,
's2b940301421633c3': `enter description here`,
's37ee620e44d1533d': `input text minimum 5-125 letters`,
's3cf0c263cd2dcba3': `Already have an account?`,
's3d5ec69a6bb3472e': `dark`,
's45dab30b4d2d3c14': `Login`,
's4b1a493507b3a318': `password`,
's4c9c0860ebbb779a': `Failed to obtain location`,
's4e88ffdb99e2ac13': `date`,
's51d0f228b37fd03e': `I want to hear your story today`,
's52c7e91ac3b4c3b1': `next`,
's55a10969ca715e1a': `home`,
's5a0a1db9e8aa5cda': `Account not found!`,
's62f49131afb567ec': `data not found`,
's63dc8e0c3a4e101c': `settings`,
's742c9c23d1339e9a': `Redirecting to login page`,
's791e05c31c49ee28': `change password`,
's7ae24e2336894d23': `Don't have an account?`,
's7e529dba6c35eb7a': `last updated`,
's839a089030f02437': `Successfully Added Story`,
's854242b8a879835a': `add story`,
's861bcba4db199cb4': `login`,
's87f398d5a8c139c0': `light`,
's90a714a4349ca0f1': `logout`,
's94a644b5e0880579': `username`,
's9a6832609fd9c1bf': `email address`,
'sa52127387350c01a': `reset settings`,
'sa7a70bfb41a338db': `password`,
'sb1a4bc14542488cb': `Failed to register account!`,
'sb265cc26dbb527f9': `change name`,
'sb56798071baac29e': `dashboard`,
'sb616cbe958dea2ee': `Login Successful`,
'sb7c4c1e6784787df': `profile`,
'sc22a9483cdfc43da': `account`,
'sc4bcb1ba8e632252': `name`,
'sd064987a26e82eb7': `change theme`,
'sd535cd6798034923': `send as`,
'sd93e3def078c6f4c': `guest`,
'sd93ff51dd0da1dbf': `Sign up`,
'sdb40d268bbd1a81c': `change language`,
'sdeec2d9bd0d9a355': `blue`,
'se96192ff1de6ff4d': `remove account`,
'seb832a602c5b48df': `Sign up`,
'sf31e8cf85d601d2a': `previous`,
'sf41b5558524d0412': `Redirecting to home`,
    };
  