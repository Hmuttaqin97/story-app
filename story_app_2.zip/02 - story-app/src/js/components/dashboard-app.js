import { html, css, LitElement } from 'lit';

class DashboardApp extends LitElement {
  static styles = css`
    .tabs {
      display: flex;
      gap: 10px;
    }
    .tab-content {
      margin-top: 15px;
    }
    .active {
      font-weight: bold;
    }
  `;

  static properties = {
    activeTab: { type: String },
  };

  constructor() {
    super();
    this.activeTab = sessionStorage.getItem('activeTab') || 'user';
  }

  _switchTab(tab) {
    this.activeTab = tab;
    sessionStorage.setItem('activeTab', tab);
  }

  render() {
    return html`
      <div class="tabs">
        <button class="${this.activeTab === 'user' ? 'active' : ''}" @click="${() => this._switchTab('user')}">User</button>
        <button class="${this.activeTab === 'guest' ? 'active' : ''}" @click="${() => this._switchTab('guest')}">Guest</button>
      </div>
      <div class="tab-content">
        ${this.activeTab === 'user' ? html`<user-table></user-table>` : html`<guest-table></guest-table>`}
      </div>
    `;
  }
}

customElements.define('dashboard-app', DashboardApp);
