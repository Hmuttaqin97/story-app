import { html } from 'lit';
import LitWithoutShadowDom from './base/LitWithoutShadowDom';
import { msg, updateWhenLocaleChanges } from '@lit/localize';

class AccountApp extends LitWithoutShadowDom {
  constructor() {
    super();
    updateWhenLocaleChanges(this);
  }

  render() {
    return html`
    <div class="account-form">
    <label-user type="name"></label-user>
    <label-user type="contact"></label-user>
    <label-user type="security"></label-user>
    <input-user type="name"></input-user>
    <input-user type="security"></input-user>
    <button type="button" class="btn btn-warning">${msg(`Delete Account`)}</button>
    </div>
    `;
  }
}

customElements.define('account-app', AccountApp);
