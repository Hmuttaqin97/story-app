
    // Do not modify this file by hand!
    // Re-generate this file by running lit-localize

    
    

    /* eslint-disable no-irregular-whitespace */
    /* eslint-disable @typescript-eslint/no-explicit-any */

    export const templates = {
      's04a2bb60eb38f246': `あなたのストーリーを追加`,
's0f136ff2c086b760': `リセット`,
's24eb6ed15e6253d7': `説明`,
's25a08d8d86e134df': `送信`,
's2b940301421633c3': `ここに説明を入力`,
's3d5ec69a6bb3472e': `暗い`,
's4b1a493507b3a318': `パスワード`,
's4e88ffdb99e2ac13': `日付`,
's51d0f228b37fd03e': `今日あなたの話を聞きたい`,
's52c7e91ac3b4c3b1': `次へ`,
's55a10969ca715e1a': `ホーム`,
's62f49131afb567ec': `データが見つかりません`,
's63dc8e0c3a4e101c': `設定`,
's791e05c31c49ee28': `パスワードを変更`,
's7e529dba6c35eb7a': `最終更新`,
's854242b8a879835a': `ストーリーを追加`,
's861bcba4db199cb4': `ログイン`,
's87f398d5a8c139c0': `明るい`,
's90a714a4349ca0f1': `ログアウト`,
's94a644b5e0880579': `ユーザー名`,
's9a6832609fd9c1bf': `メールアドレス`,
'sa52127387350c01a': `設定をリセット`,
'sb265cc26dbb527f9': `名前を変更`,
'sb56798071baac29e': `ダッシュボード`,
'sb7c4c1e6784787df': `プロフィール`,
'sc22a9483cdfc43da': `アカウント`,
'sd064987a26e82eb7': `テーマを変更`,
'sd535cd6798034923': `として送信`,
'sd93e3def078c6f4c': `ゲスト`,
'sdb40d268bbd1a81c': `言語を変更`,
'sdeec2d9bd0d9a355': `青`,
'se889b38b74f47e2d': `最小10〜125文字のテキストを入力してください`,
'se96192ff1de6ff4d': `アカウントを削除する`,
'sf31e8cf85d601d2a': `前へ`,
    };
  