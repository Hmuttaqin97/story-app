
    // Do not modify this file by hand!
    // Re-generate this file by running lit-localize

    
    

    /* eslint-disable no-irregular-whitespace */
    /* eslint-disable @typescript-eslint/no-explicit-any */

    export const templates = {
      's04a2bb60eb38f246': `add your story`,
's0f136ff2c086b760': `reset`,
's24eb6ed15e6253d7': `description`,
's25a08d8d86e134df': `send`,
's2b940301421633c3': `enter description here`,
's3d5ec69a6bb3472e': `dark`,
's4b1a493507b3a318': `password`,
's4e88ffdb99e2ac13': `date`,
's51d0f228b37fd03e': `I want to hear your story today`,
's52c7e91ac3b4c3b1': `next`,
's55a10969ca715e1a': `home`,
's62f49131afb567ec': `data not found`,
's63dc8e0c3a4e101c': `settings`,
's791e05c31c49ee28': `change password`,
's7e529dba6c35eb7a': `last updated`,
's854242b8a879835a': `add story`,
's861bcba4db199cb4': `login`,
's87f398d5a8c139c0': `light`,
's90a714a4349ca0f1': `logout`,
's94a644b5e0880579': `username`,
's9a6832609fd9c1bf': `email address`,
'sa52127387350c01a': `reset settings`,
'sb265cc26dbb527f9': `change name`,
'sb56798071baac29e': `dashboard`,
'sb7c4c1e6784787df': `profile`,
'sc22a9483cdfc43da': `account`,
'sd064987a26e82eb7': `change theme`,
'sd535cd6798034923': `send as`,
'sd93e3def078c6f4c': `guest`,
'sdb40d268bbd1a81c': `change language`,
'sdeec2d9bd0d9a355': `blue`,
'se889b38b74f47e2d': `enter text minimum 10-125 characters`,
'se96192ff1de6ff4d': `remove account`,
'sf31e8cf85d601d2a': `previous`,
    };
  