import { html, css } from 'lit';
import LitWithoutShadowDom from './base/LitWithoutShadowDom';

class FooterApp extends LitWithoutShadowDom {
  static styles = css`
    .social-links a {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      width: 40px;
      height: 40px;
      margin: 5px;
      border-radius: 50%;
      color: white;
      text-decoration: none;
      transition: 0.3s;
    }
    .social-links a:hover {
      opacity: 0.8;
    }
    .footer-text {
      text-align: center;
      padding: 10px;
      background-color: rgba(0, 0, 0, 0.05);
    }
  `;

  render() {
    return html`
      <div class="container p-4 pb-0">
        <section class="social-links mb-4 text-center">
          ${this.renderSocialLink('instagram', '#ac2bac', 'https://www.instagram.com/muh_hanif_m')}
          ${this.renderSocialLink('linkedin', '#0082ca', 'https://www.linkedin.com/in/muhammad-hanif-mutaqqin-811902157/')}
          ${this.renderSocialLink('github', '#333333', 'https://github.com/Hmuttaqin97')}
          ${this.renderSocialLink('whatsapp', '#3b5998', 'https://wa.me/+6287829643034')}
        </section>
      </div>
      <div class="footer-text">
        © 2024 Copyright:
        <a class="text-body" href="https://t.me/MuhHanifMlink">s.id/MuhHanifMlink</a>
      </div>
    `;
  }

  renderSocialLink(platform, color, url) {
    return html`
      <a class="btn text-white btn-floating" style="background-color: ${color};" href="${url}" role="button">
        <i class="bi bi-${platform}"></i>
      </a>
    `;
  }
}

customElements.define('footer-app', FooterApp);
